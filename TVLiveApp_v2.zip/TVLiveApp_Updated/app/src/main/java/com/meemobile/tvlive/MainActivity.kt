package com.meemobile.tvlive

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

// ─── Data Models ──────────────────────────────────────────────────────────────

data class EpgEntry(
    val title: String,
    val startHour: Int,
    val startMin: Int,
    val endHour: Int,
    val endMin: Int
)

data class Channel(
    val name: String,
    val url: String,
    val category: String = "ทั่วไป",
    val epg: List<EpgEntry> = emptyList()
)

// ─── Main Activity ─────────────────────────────────────────────────────────────

class MainActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var rvChannels: RecyclerView
    private lateinit var tvNowPlaying: TextView
    private lateinit var tvEpgCurrent: TextView
    private lateinit var tvEpgNext: TextView
    private lateinit var tvEpgTime: TextView
    private lateinit var tvBuffering: TextView
    private lateinit var tvLiveBadge: TextView
    private lateinit var pbLoading: ProgressBar

    private var currentChannelIndex = 0
    private var adapter: ChannelAdapter? = null
    private val epgHandler = Handler(Looper.getMainLooper())
    private val epgRunnable = object : Runnable {
        override fun run() {
            updateEpgDisplay()
            epgHandler.postDelayed(this, 60_000) // refresh every minute
        }
    }

    // ─── Channel List ─────────────────────────────────────────────────────────
    private val channelList = listOf(

        // ── Free TV / ทีวีดิจิทัล ──────────────────────────────────────────
        Channel(
            name = "Thai PBS",
            url = "https://thaipbs-live.cdn.byteark.com/live/playlist.m3u8",
            category = "ทีวีดิจิทัล",
            epg = listOf(
                EpgEntry("ข่าวเช้า Thai PBS", 6, 0, 9, 0),
                EpgEntry("รายการเด็กและเยาวชน", 9, 0, 11, 0),
                EpgEntry("ตามสายลม", 11, 0, 12, 0),
                EpgEntry("ข่าวเที่ยง", 12, 0, 13, 0),
                EpgEntry("สารคดีธรรมชาติ", 13, 0, 15, 0),
                EpgEntry("รายการสุขภาพ", 15, 0, 17, 0),
                EpgEntry("ข่าวเย็น Thai PBS", 17, 0, 18, 30),
                EpgEntry("ข่าวค่ำ Thai PBS", 20, 0, 21, 0),
                EpgEntry("สารคดีพิเศษ", 21, 0, 23, 0)
            )
        ),
        Channel(
            name = "NBT",
            url = "https://nbt.m-society.go.th/live/playlist.m3u8",
            category = "ทีวีดิจิทัล",
            epg = listOf(
                EpgEntry("ข่าวเช้า NBT", 6, 0, 8, 0),
                EpgEntry("รายการสาระ", 8, 0, 10, 0),
                EpgEntry("รายการบันเทิง", 10, 0, 12, 0),
                EpgEntry("ข่าวเที่ยง NBT", 12, 0, 13, 0),
                EpgEntry("รายการท่องเที่ยว", 13, 0, 15, 0),
                EpgEntry("ข่าวบ่าย NBT", 15, 0, 17, 0),
                EpgEntry("ข่าวเย็น NBT", 17, 0, 19, 0),
                EpgEntry("ข่าวค่ำ NBT", 20, 0, 21, 0),
                EpgEntry("รายการวาไรตี้", 21, 0, 23, 0)
            )
        ),
        Channel(
            name = "ALTV ช่อง 4",
            url = "https://altv-live.cdn.byteark.com/live/playlist.m3u8",
            category = "ทีวีดิจิทัล",
            epg = listOf(
                EpgEntry("รายการเด็ก ALTV", 7, 0, 9, 0),
                EpgEntry("รายการการศึกษา", 9, 0, 12, 0),
                EpgEntry("ข่าวเที่ยง ALTV", 12, 0, 13, 0),
                EpgEntry("รายการบันเทิง", 13, 0, 17, 0),
                EpgEntry("ข่าวค่ำ ALTV", 18, 0, 19, 0),
                EpgEntry("ละครไทย", 20, 0, 22, 0),
                EpgEntry("รายการดึก", 22, 0, 0, 0)
            )
        ),
        Channel(
            name = "ช่อง 3 HD",
            url = "https://live.ch3thailand.com/ch3hd/playlist.m3u8",
            category = "ทีวีดิจิทัล",
            epg = listOf(
                EpgEntry("ข่าวเช้า 3", 6, 0, 8, 30),
                EpgEntry("รายการเช้าวันนี้", 8, 30, 11, 0),
                EpgEntry("ข่าวเที่ยง 3", 12, 0, 13, 0),
                EpgEntry("ละครบ่าย", 13, 0, 17, 0),
                EpgEntry("ข่าว 3 มิติ", 17, 0, 18, 0),
                EpgEntry("ข่าว 3 ทุ่ม", 21, 0, 22, 0),
                EpgEntry("ละครค่ำช่อง 3", 20, 0, 21, 0)
            )
        ),
        Channel(
            name = "ช่อง 7 HD",
            url = "https://live.ch7hd.com/ch7hd/playlist.m3u8",
            category = "ทีวีดิจิทัล",
            epg = listOf(
                EpgEntry("ข่าวเช้า 7 สี", 6, 0, 9, 0),
                EpgEntry("รายการวาไรตี้เช้า", 9, 0, 12, 0),
                EpgEntry("ข่าวเที่ยง 7 สี", 12, 0, 13, 0),
                EpgEntry("ละครบ่าย", 13, 0, 17, 0),
                EpgEntry("ข่าวเย็น 7 สี", 17, 0, 18, 30),
                EpgEntry("ละครค่ำ 7 สี", 20, 0, 22, 0),
                EpgEntry("ข่าว 7 สีค่ำ", 22, 0, 23, 0)
            )
        ),

        // ── ข่าว / News ────────────────────────────────────────────────────
        Channel(
            name = "TNN 16",
            url = "https://tnn.tv/live/tnn16/playlist.m3u8",
            category = "ข่าว",
            epg = listOf(
                EpgEntry("TNN ข่าวเช้า", 5, 0, 9, 0),
                EpgEntry("TNN ข่าวสาย", 9, 0, 12, 0),
                EpgEntry("TNN ข่าวเที่ยง", 12, 0, 13, 0),
                EpgEntry("TNN ข่าวบ่าย", 13, 0, 17, 0),
                EpgEntry("TNN ข่าวเย็น", 17, 0, 20, 0),
                EpgEntry("TNN ข่าวค่ำ", 20, 0, 21, 0),
                EpgEntry("TNN ข่าวดึก", 21, 0, 0, 0)
            )
        ),
        Channel(
            name = "Nation TV",
            url = "https://nationtv.tv/live/playlist.m3u8",
            category = "ข่าว",
            epg = listOf(
                EpgEntry("เนชั่นข่าวเช้า", 6, 0, 9, 0),
                EpgEntry("เนชั่นสาย", 9, 0, 12, 0),
                EpgEntry("เนชั่นเที่ยง", 12, 0, 13, 0),
                EpgEntry("เนชั่นบ่าย", 13, 0, 17, 0),
                EpgEntry("เนชั่นเย็น", 17, 0, 20, 0),
                EpgEntry("เนชั่นค่ำ", 20, 0, 22, 0)
            )
        ),

        // ── บันเทิง / Entertainment ────────────────────────────────────────
        Channel(
            name = "ONE 31",
            url = "https://live.one31.tv/one31hd/playlist.m3u8",
            category = "บันเทิง",
            epg = listOf(
                EpgEntry("รายการเช้า ONE", 7, 0, 10, 0),
                EpgEntry("ซีรีส์เกาหลี", 10, 0, 13, 0),
                EpgEntry("ซีรีส์ยอดฮิต", 13, 0, 17, 0),
                EpgEntry("ข่าวบันเทิง", 17, 0, 18, 0),
                EpgEntry("ละครไทยพรีเมียม", 20, 0, 22, 0),
                EpgEntry("รายการค่ำคืน", 22, 0, 0, 0)
            )
        ),
        Channel(
            name = "GMM 25",
            url = "https://live.gmm25.com/gmm25hd/playlist.m3u8",
            category = "บันเทิง",
            epg = listOf(
                EpgEntry("รายการเช้า GMM", 7, 0, 10, 0),
                EpgEntry("รายการวาไรตี้", 10, 0, 13, 0),
                EpgEntry("ซีรีส์วัยรุ่น", 13, 0, 17, 0),
                EpgEntry("รายการบันเทิง", 17, 0, 20, 0),
                EpgEntry("ละครพรีเมียม GMM", 20, 0, 22, 0),
                EpgEntry("รายการดึก GMM", 22, 0, 0, 0)
            )
        ),

        // ── กีฬา / Sports ──────────────────────────────────────────────────
        Channel(
            name = "True Sport 1",
            url = "https://live.truesport.com/ts1/playlist.m3u8",
            category = "กีฬา",
            epg = listOf(
                EpgEntry("ไฮไลท์กีฬา", 7, 0, 9, 0),
                EpgEntry("ถ่ายทอดสด", 9, 0, 13, 0),
                EpgEntry("วิเคราะห์กีฬา", 13, 0, 15, 0),
                EpgEntry("ฟุตบอลสด", 18, 0, 20, 0),
                EpgEntry("ฟุตบอลยุโรป", 20, 0, 23, 0)
            )
        )
    )

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupChannelList()
        initializePlayer()
        playChannel(currentChannelIndex)
        epgHandler.post(epgRunnable)
    }

    override fun onStart() {
        super.onStart()
        if (player == null) {
            initializePlayer()
            playChannel(currentChannelIndex)
        }
    }

    override fun onResume() {
        super.onResume()
        player?.play()
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    override fun onDestroy() {
        super.onDestroy()
        epgHandler.removeCallbacks(epgRunnable)
    }

    // ─── View Binding ─────────────────────────────────────────────────────────

    private fun bindViews() {
        playerView    = findViewById(R.id.player_view)
        rvChannels    = findViewById(R.id.rv_channels)
        tvNowPlaying  = findViewById(R.id.tv_now_playing)
        tvEpgCurrent  = findViewById(R.id.tv_epg_current)
        tvEpgNext     = findViewById(R.id.tv_epg_next)
        tvEpgTime     = findViewById(R.id.tv_epg_time)
        tvBuffering   = findViewById(R.id.tv_buffering)
        tvLiveBadge   = findViewById(R.id.tv_live_badge)
        pbLoading     = findViewById(R.id.pb_loading)
    }

    // ─── Player ───────────────────────────────────────────────────────────────

    private fun initializePlayer() {
        player = ExoPlayer.Builder(this).build().also { exoPlayer ->
            playerView.player = exoPlayer
            exoPlayer.addListener(object : Player.Listener {

                override fun onPlaybackStateChanged(playbackState: Int) {
                    when (playbackState) {
                        Player.STATE_BUFFERING -> {
                            pbLoading.visibility = View.VISIBLE
                            tvBuffering.visibility = View.VISIBLE
                            tvLiveBadge.visibility = View.GONE
                        }
                        Player.STATE_READY -> {
                            pbLoading.visibility = View.GONE
                            tvBuffering.visibility = View.GONE
                            tvLiveBadge.visibility = View.VISIBLE
                        }
                        Player.STATE_IDLE, Player.STATE_ENDED -> {
                            pbLoading.visibility = View.GONE
                            tvBuffering.visibility = View.GONE
                            tvLiveBadge.visibility = View.GONE
                        }
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    pbLoading.visibility = View.GONE
                    tvBuffering.visibility = View.GONE
                    tvLiveBadge.visibility = View.GONE
                    Toast.makeText(
                        this@MainActivity,
                        "⚠️ โหลดสตรีมไม่ได้: ${channelList[currentChannelIndex].name}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })
        }
    }

    private fun playChannel(index: Int) {
        if (index < 0 || index >= channelList.size) return
        currentChannelIndex = index
        val channel = channelList[index]

        player?.run {
            stop()
            setMediaItem(MediaItem.fromUri(channel.url))
            prepare()
            playWhenReady = true
        }

        tvNowPlaying.text = channel.name
        updateEpgDisplay()
        adapter?.setSelectedIndex(index)
    }

    private fun releasePlayer() {
        player?.release()
        player = null
    }

    // ─── EPG ──────────────────────────────────────────────────────────────────

    private fun updateEpgDisplay() {
        val channel = channelList.getOrNull(currentChannelIndex) ?: return
        val cal = Calendar.getInstance()
        val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)

        val current = channel.epg.firstOrNull { entry ->
            val start = entry.startHour * 60 + entry.startMin
            val end   = if (entry.endHour == 0 && entry.endMin == 0) 24 * 60
                        else entry.endHour * 60 + entry.endMin
            nowMin in start until end
        }
        val next = channel.epg.firstOrNull { entry ->
            val start = entry.startHour * 60 + entry.startMin
            start > nowMin
        }

        val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

        if (current != null) {
            tvEpgCurrent.text = "▶ ${current.title}"
            tvEpgTime.text = "${String.format("%02d:%02d", current.startHour, current.startMin)} – " +
                             "${String.format("%02d:%02d", current.endHour, current.endMin)}"
            tvEpgCurrent.visibility = View.VISIBLE
            tvEpgTime.visibility = View.VISIBLE
        } else {
            tvEpgCurrent.visibility = View.GONE
            tvEpgTime.visibility = View.GONE
        }

        if (next != null) {
            tvEpgNext.text = "ถัดไป: ${next.title}  ${String.format("%02d:%02d", next.startHour, next.startMin)}"
            tvEpgNext.visibility = View.VISIBLE
        } else {
            tvEpgNext.visibility = View.GONE
        }
    }

    // ─── RecyclerView ─────────────────────────────────────────────────────────

    private fun setupChannelList() {
        adapter = ChannelAdapter(channelList) { index -> playChannel(index) }
        rvChannels.layoutManager = LinearLayoutManager(this)
        rvChannels.adapter = adapter
        rvChannels.setHasFixedSize(true)
    }

    // ─── Adapter ──────────────────────────────────────────────────────────────

    inner class ChannelAdapter(
        private val channels: List<Channel>,
        private val onClick: (Int) -> Unit
    ) : RecyclerView.Adapter<ChannelAdapter.ViewHolder>() {

        private var selectedIndex = 0

        fun setSelectedIndex(index: Int) {
            val old = selectedIndex
            selectedIndex = index
            notifyItemChanged(old)
            notifyItemChanged(index)
        }

        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvName: TextView     = view.findViewById(R.id.tv_channel_name)
            val tvCategory: TextView = view.findViewById(R.id.tv_channel_category)
            val ivPlay: ImageView    = view.findViewById(R.id.iv_play_indicator)
            val cardRoot: View       = view.findViewById(R.id.card_root)

            init {
                view.setOnClickListener { onClick(adapterPosition) }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_channel, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val ch = channels[position]
            holder.tvName.text = ch.name
            holder.tvCategory.text = ch.category

            val isSelected = position == selectedIndex
            holder.cardRoot.setBackgroundResource(
                if (isSelected) R.drawable.bg_channel_selected else R.drawable.bg_channel_normal
            )
            holder.tvName.setTextColor(
                ContextCompat.getColor(
                    holder.itemView.context,
                    if (isSelected) R.color.accent else android.R.color.white
                )
            )
            holder.ivPlay.visibility = if (isSelected) View.VISIBLE else View.GONE
        }

        override fun getItemCount() = channels.size
    }
}
